using UnityEngine;
using UnityEngine.UI;
using System;
using TMPro;

public class SunControlUI : MonoBehaviour
{
    public Slider timeOfDaySlider;
    public TextMeshProUGUI dateTimeText;
    public SunPosition sun;

    void Start()
    {
        timeOfDaySlider.onValueChanged.AddListener(UpdateTimeOfDay);
        UpdateUI();
    }

    void UpdateTimeOfDay(float sliderValue)
    {
        int newHour = Mathf.FloorToInt(sliderValue / 60);
        int newMinute = Mathf.FloorToInt(sliderValue % 60);
        sun.SetNewDate(new DateTime(sun.year, sun.month, sun.day, newHour, newMinute, 0));
        UpdateUI();
    }

    void UpdateUI()
    {
        dateTimeText.text = $"Date: {sun.month}/{sun.day}/{sun.year} - Time: {sun.hour:D2}:{sun.minute:D2}";
    }
}
