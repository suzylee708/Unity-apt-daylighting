﻿using UnityEngine;
using System;

public class SunPosition : MonoBehaviour
{
    public double latitude = 40.7128;  // NYC Latitude
    public double longitude = -74.0060; // NYC Longitude
    public int year = 2024;
    public int month = 6;
    public int day = 21;
    public int hour = 12;
    public int minute = 0;

    public void SetNewDate(DateTime newDate)
    {
        year = newDate.Year;
        month = newDate.Month;
        day = newDate.Day;
        hour = newDate.Hour;
        minute = newDate.Minute;
        UpdateSunPosition();
    }

    void UpdateSunPosition()
    {
        double altitude, azimuth;
        CalculateSunPosition(latitude, longitude, year, month, day, hour, minute, out altitude, out azimuth);
        transform.eulerAngles = new Vector3((float)altitude, (float)azimuth, 0);
    }

    void CalculateSunPosition(double lat, double lon, int year, int month, int day, int hour, int min, out double altitude, out double azimuth)
    {
        // Placeholder for actual sun calculation (you can use a solar position library)
        altitude = 45.0;
        azimuth = 180.0;
    }
}
